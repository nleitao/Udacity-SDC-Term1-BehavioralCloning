
Project 3 - Behavioral Cloning

Problem to solve: Train a neural network capable of driving a car in a simulation environment.
This training is done with the input information (on this case images) captured from the simulator and the respective steering angle for each set of images (they will work as labels/outputs).

The training set used was the one provided by Udacity.
I've tried to create my own training data by recording myself running the simulator but I found that the angles were too "sharp/extreme".
Only images from the centre camera were used in this project.

Image pre-processing:
All the training images were pre-processed in order to make it easier for the NN to classify them:
-Normalization
-Augment brightness (after my mentor suggested me to see a medium.com account - https://medium.com/@vivek.yadav/improved-performance-of-deep-learning-neural-network-models-on-traffic-sign-classification-using-6355346da2dc#.n4wqmiwzc)
-Image crop to try to better isolate the road/lines (training images were crop from the top until nearly the middle point of the image and from the bottom until the top of the bonnet)
-All images were later converted to float16 to make the training more "resource friendly". I didn't find any major loss of accuracy by reducing the size/type of data.
-To reduce the memory necessary to train the model the images were shrunk to 40x160 (initial being 160,320)   

                     
                     
From this original training set, 10% was reserved for testing the model, and from the remaining 90%, 20% served as validation set.


Model architecture:
I've started using the model architecture used in the Keras lab, but when I was running the model in the simulation the car was sent off road after entering the first curve.
I've added a couple more convolution layers, more fully connected layers alongside with dropouts to prevent overfitting.
Here is the final model architecture after several sessions of trial and error:

Input shape: Image set with dimension 40x160
Layer 1: Convolution, 64 output filters, kernel 3x3, with Max Pooling 2x2 and with ELU activation
Layer 2: Convolution, 32 output filters, kernel 3x3, with Max Pooling 2x2 and with ELU activation
Layer 3: Convolution, 16 output filters, kernel 3x3, with Max Pooling 2x2 and with ELU activation
Layer 4: Convolution, 8 output filters, kernel 3x3, with ELU activation and with 50% dropout
Layer 5: Output flattening
Layer 6: Fully connected layer with 160 outputs and ELU activation
Layer 7: Fully connected layer with 160 outputs and ELU activation
Layer 8: Fully connected layer with 160 outputs and ELU activation
Layer 9: Fully connected layer with 128 outputs and ELU activation
Layer 9: Fully connected layer with 128 outputs and ELU activation
Layer 10: Fully connected layer with 64 outputs and ELU activation
Layer 11: Fully connected layer with 64 outputs and ELU activation
Layer 12: Fully connected layer with 32 outputs and ELU activation
Layer 13: Fully connected layer with 32 outputs, ELU activation and 50% dropout
Final Layer: FCL with 1 output -> steering angle

                     
Some notes regarding model architecture:                     
after a couple of trial and error iterations I had the error InvalidArgumentError: Received a label value of 1 which is outside the valid range of [0, 1).  Label values: 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0
Saw somebody with the same problem in the forum and it was recommended to check activation functions on keras docs (https://carnd-forums.udacity.com/questions/35229158/p3-avoid-predicted-steering-angles-outside-0-1-)
The error function was changed from "sparse_categorical_crossentropy" to "mean square error" because of this.
It was also suggested to change the activation functions and after going back and forth with TANH/ELU/RELU, it seems that ELU was giving better results.

Model training:
To train the model an Adam optimizer was used.
The error function chosen was mean square error as stated before.
I've started to train the model with 10 epochs, but as stated in the "Further Help" topic provided by Udacity (https://carnd-forums.udacity.com/questions/26214464/behavioral-cloning-cheatsheet), 5 epochs were enough.

After the model is trained, the weights and model info are saved respectively to model.h5 and model.json.

Extra notes:
-I found it very difficult to assess my model since with all the iterations that I have done (add layer, change epochs, change batch size, max pooling, dropouts etc.) the training accuracy was always between 0.45-0.55
-The only method to see if I was going on the right direction was to run the model/simulation



```python

```
